// ============================================================================
// api/garmin/status.js — Garmin connection state for the admin dashboard
// ============================================================================

import { bootstrap as bootstrapSheets } from '../../lib/sheets.js';
import { bootstrapGarmin, getStatus } from '../../lib/garmin.js';
import { recentFlags } from '../../lib/garminTriggers.js';

const DASHBOARD_TOKEN = process.env.DASHBOARD_TOKEN;

export default async function handler(req, res) {
  const key = req.query.key || '';
  if (!DASHBOARD_TOKEN || key !== DASHBOARD_TOKEN) {
    return res.status(401).json({ ok: false, reason: 'unauthorized' });
  }
  if (req.method !== 'GET') {
    return res.status(405).json({ ok: false, reason: 'method_not_allowed' });
  }
  try {
    await bootstrapSheets();
    await bootstrapGarmin();
    const status = await getStatus();
    const flags = status.linked ? await recentFlags(14) : [];
    return res.status(200).json({ ...status, recent_flags: flags });
  } catch (err) {
    console.error('[garmin/status]', err);
    return res.status(500).json({ ok: false, reason: err.message });
  }
}
