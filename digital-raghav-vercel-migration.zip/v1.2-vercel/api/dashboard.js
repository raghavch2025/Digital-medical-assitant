// ============================================================================
// api/dashboard.js — read-only HTML dashboard
// ============================================================================
// GET /api/dashboard?key=DASHBOARD_TOKEN
// Returns the dashboard.html file from V1.1 (or v1.2 admin if you want).
// The file itself does its own data-fetching from the other /api endpoints
// via the same DASHBOARD_TOKEN.
//
// We could put dashboard.html in /public and let Vercel serve it as a
// static file — but then we'd lose the auth gate. Serving it through a
// function lets us check the key before sending bytes.
// ============================================================================

import { readFile } from 'node:fs/promises';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const DASHBOARD_TOKEN = process.env.DASHBOARD_TOKEN;

let cachedHtml = null;

async function loadDashboard() {
  if (cachedHtml) return cachedHtml;
  // The HTML lives in lib/ alongside the rest of the code, so Vercel
  // bundles it with the function.
  const path = join(__dirname, '..', 'lib', 'dashboard.html');
  cachedHtml = await readFile(path, 'utf8');
  return cachedHtml;
}

export default async function handler(req, res) {
  const key = req.query.key || '';
  if (!DASHBOARD_TOKEN || key !== DASHBOARD_TOKEN) {
    return res.status(401).send('unauthorized');
  }

  try {
    const html = await loadDashboard();
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    return res.status(200).send(html);
  } catch (err) {
    console.error('[dashboard] error:', err);
    return res.status(500).send(`error: ${err.message}`);
  }
}
