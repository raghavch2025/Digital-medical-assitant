// ============================================================================
// api/nudge.js — send a manual nudge from the dashboard
// ============================================================================
// POST /api/nudge?key=DASHBOARD_TOKEN
// Body: { body: "the message", acknowledgeWarnings?: boolean }
// Same contract as V1.1's /api/nudge — the dashboard already knows how to
// call this. Tone warnings, rate limits etc. live in lib/nudge.js.
// ============================================================================

import { bootstrap as bootstrapSheets } from '../lib/sheets.js';
import { sendNudge } from '../lib/nudge.js';

const DASHBOARD_TOKEN = process.env.DASHBOARD_TOKEN;

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ ok: false, reason: 'method_not_allowed' });
  }
  const key = req.query.key || '';
  if (!DASHBOARD_TOKEN || key !== DASHBOARD_TOKEN) {
    return res.status(401).json({ ok: false, reason: 'unauthorized' });
  }

  // Vercel auto-parses JSON bodies for POST requests with content-type:
  // application/json. If it doesn't, we'd need a small parser — but the
  // dashboard sends JSON so this should be fine.
  const { body, acknowledgeWarnings = false } = req.body || {};
  if (!body || typeof body !== 'string') {
    return res.status(400).json({ ok: false, reason: 'body_required' });
  }
  if (body.length > 500) {
    return res.status(400).json({ ok: false, reason: 'body_too_long' });
  }

  try {
    await bootstrapSheets();
    const result = await sendNudge({ body: body.trim(), acknowledgeWarnings });
    return res.status(result.ok ? 200 : 400).json(result);
  } catch (err) {
    console.error('[nudge] error:', err);
    return res.status(500).json({ ok: false, reason: err.message });
  }
}
