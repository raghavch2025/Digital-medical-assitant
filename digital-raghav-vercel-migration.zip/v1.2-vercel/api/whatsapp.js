// ============================================================================
// api/whatsapp.js — Twilio inbound webhook
// ============================================================================
// Twilio POSTs to this URL whenever Madhav or Raghav sends a WhatsApp
// message. We respond with empty TwiML (200) immediately so Twilio knows
// we received it, then we route the message in the background via the
// existing parser/handlers.
//
// IMPORTANT: respond with TwiML BEFORE awaiting any handler work, otherwise
// Twilio will retry after a few seconds and we'll process the message twice.
// We use Promise.resolve().then(...) for fire-and-forget after the response.
//
// On Vercel, the function instance stays alive until the response is sent.
// Background work after res.end() may be killed if the instance is reused
// before completion. To be safe, we await handler work BEFORE responding.
// Twilio's webhook timeout is 15 seconds which gives plenty of headroom for
// our typical work (<5s).
// ============================================================================

import { bootstrap as bootstrapSheets } from '../lib/sheets.js';
import { bootstrapConfigStore } from '../lib/configStore.js';
import { parseInbound, emptyTwimlResponse, sendMessage } from '../lib/whatsapp.js';
import { parse, TYPES } from '../lib/parser.js';
import { handleMadhavMessage } from '../lib/handlers/madhav.js';
import {
  isAdmin,
  parseAdminCommand,
  executeAdminCommand,
} from '../lib/handlers/admin.js';
import { parseAdminNL } from '../lib/adminNLParser.js';
import { generateDoctorBrief } from '../lib/briefGenerator.js';

let bootstrapped = false;
async function ensureBootstrap() {
  if (bootstrapped) return;
  await bootstrapSheets();
  await bootstrapConfigStore();
  bootstrapped = true;
}

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).type('text/xml').send(emptyTwimlResponse());
  }

  try {
    await ensureBootstrap();
  } catch (err) {
    console.error('[whatsapp] bootstrap failed:', err);
    // Still respond 200 so Twilio doesn't retry; we'll try again next message
    return res.status(200).type('text/xml').send(emptyTwimlResponse());
  }

  const inbound = parseInbound(req);
  const { from, text } = inbound;

  // Vercel parses form-encoded bodies automatically in Node serverless funcs.
  // If we ever switch runtimes, we may need to add bodyParser.
  console.log(`[whatsapp] from=${from} text=${(text || '').slice(0, 60)}`);

  try {
    if (isAdmin(from)) {
      await handleRaghavMessage(from, text);
    } else {
      // Madhav (or anyone else — handler decides what to do)
      const parsed = parse(text);
      await handleMadhavMessage(from, text, parsed);
    }
  } catch (err) {
    console.error('[whatsapp] handler error:', err);
    // Don't bubble — Twilio retries cause duplicates
  }

  return res.status(200).type('text/xml').send(emptyTwimlResponse());
}

async function handleRaghavMessage(from, text) {
  // 1. Slash command
  let adminCmd = parseAdminCommand(text);

  // 2. NL fallback
  if (!adminCmd && text && !text.startsWith('/')) {
    const translated = await parseAdminNL(text);
    if (translated) {
      console.log(`[admin] NL "${text}" → "${translated}"`);
      adminCmd = parseAdminCommand(translated);
    }
  }

  if (adminCmd) {
    if (adminCmd.type === 'brief_passthrough') {
      const brief = await generateDoctorBrief();
      await sendMessage(from, brief);
      return;
    }
    if (adminCmd.type === 'status_passthrough') {
      const status = await generateDoctorBrief({ days: 7 });
      await sendMessage(from, status);
      return;
    }
    const reply = await executeAdminCommand(adminCmd, from);
    if (reply) await sendMessage(from, reply);
    return;
  }

  // Backward-compat: V1.1 plain /brief command
  if (text && /^\/brief\b/i.test(text)) {
    const brief = await generateDoctorBrief();
    await sendMessage(from, brief);
    return;
  }

  await sendMessage(from,
    'not a command — use /say <text> to message Madhav, or /help for commands');
}
