// ============================================================================
// api/config/schedule.js — GET + POST the full medication schedule
// ============================================================================

import { bootstrap as bootstrapSheets } from '../../lib/sheets.js';
import { bootstrapConfigStore } from '../../lib/configStore.js';
import {
  getScheduleHandler,
  postScheduleHandler,
} from '../../lib/handlers/admin.js';

const DASHBOARD_TOKEN = process.env.DASHBOARD_TOKEN;

export default async function handler(req, res) {
  const key = req.query.key || '';
  if (!DASHBOARD_TOKEN || key !== DASHBOARD_TOKEN) {
    return res.status(401).json({ ok: false, reason: 'unauthorized' });
  }

  try {
    await bootstrapSheets();
    await bootstrapConfigStore();

    if (req.method === 'GET')  return getScheduleHandler(req, res);
    if (req.method === 'POST') return postScheduleHandler(req, res);
    return res.status(405).json({ ok: false, reason: 'method_not_allowed' });
  } catch (err) {
    console.error('[config/schedule]', err);
    return res.status(500).json({ ok: false, reason: err.message });
  }
}
