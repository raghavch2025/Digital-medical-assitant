// ============================================================================
// api/config/threshold.js — POST a single threshold update
// ============================================================================

import { bootstrap as bootstrapSheets } from '../../lib/sheets.js';
import { bootstrapConfigStore } from '../../lib/configStore.js';
import { postThresholdHandler } from '../../lib/handlers/admin.js';

const DASHBOARD_TOKEN = process.env.DASHBOARD_TOKEN;

export default async function handler(req, res) {
  const key = req.query.key || '';
  if (!DASHBOARD_TOKEN || key !== DASHBOARD_TOKEN) {
    return res.status(401).json({ ok: false, reason: 'unauthorized' });
  }
  if (req.method !== 'POST') {
    return res.status(405).json({ ok: false, reason: 'method_not_allowed' });
  }

  try {
    await bootstrapSheets();
    await bootstrapConfigStore();
    return postThresholdHandler(req, res);
  } catch (err) {
    console.error('[config/threshold]', err);
    return res.status(500).json({ ok: false, reason: err.message });
  }
}
