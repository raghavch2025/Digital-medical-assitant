// ============================================================================
// api/garmin-poll.js — daily Garmin Connect pull
// ============================================================================
// Hit by cron-job.org once daily at 06:00 IST. Pulls yesterday's wellness
// data from Garmin and writes a row to the GarminRaw sheet. Then evaluates
// triggers and writes flags to GarminFlags.
//
// Returns 200 even if Garmin is disabled (so cron-job.org doesn't email you
// every morning about a "failure" that's actually intentional).
// ============================================================================

import { isAuthorizedCron } from '../lib/tickAuth.js';
import { bootstrap as bootstrapSheets } from '../lib/sheets.js';
import { bootstrapConfigStore } from '../lib/configStore.js';
import { bootstrapGarmin, pollYesterday, isGarminEnabled } from '../lib/garmin.js';
import { evaluateTriggers } from '../lib/garminTriggers.js';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ ok: false, reason: 'method_not_allowed' });
  }
  if (!isAuthorizedCron(req)) {
    return res.status(401).json({ ok: false, reason: 'unauthorized' });
  }

  try {
    await bootstrapSheets();
    await bootstrapConfigStore();
    await bootstrapGarmin();

    if (!isGarminEnabled()) {
      return res.status(200).json({ ok: true, skipped: true, reason: 'garmin_disabled' });
    }

    const poll = await pollYesterday();
    const evals = await evaluateTriggers();
    return res.status(200).json({ ok: true, poll, evaluations: evals });
  } catch (err) {
    console.error('[garmin-poll] error:', err);
    return res.status(500).json({ ok: false, reason: err.message });
  }
}
