// ============================================================================
// api/brief.js — on-demand doctor brief
// ============================================================================
// GET /api/brief?key=DASHBOARD_TOKEN[&days=60][&format=html|text]
// Generates the brief and returns it. Reachable from a browser (so you can
// share with Dr. Anand) or from your phone.
// ============================================================================

import { bootstrap as bootstrapSheets } from '../lib/sheets.js';
import { bootstrapConfigStore } from '../lib/configStore.js';
import { generateDoctorBrief } from '../lib/briefGenerator.js';

const DASHBOARD_TOKEN = process.env.DASHBOARD_TOKEN;

export default async function handler(req, res) {
  const key = req.query.key || '';
  if (!DASHBOARD_TOKEN || key !== DASHBOARD_TOKEN) {
    return res.status(401).send('unauthorized');
  }

  try {
    await bootstrapSheets();
    await bootstrapConfigStore();

    const days = Math.min(Number(req.query.days || 60), 180);
    const format = req.query.format === 'html' ? 'html' : 'text';

    const brief = await generateDoctorBrief({ days });

    if (format === 'html') {
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      return res.status(200).send(renderHtml(brief, days));
    }

    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    return res.status(200).send(brief);
  } catch (err) {
    console.error('[brief] error:', err);
    return res.status(500).json({ ok: false, reason: err.message });
  }
}

function renderHtml(brief, days) {
  // Plain HTML, no framework — just enough for it to be readable in a browser
  // and printable as PDF if you want to hand it to the doctor.
  const safe = brief
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<title>Madhav — ${days}d Brief</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
  body { font: 15px/1.55 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
         max-width: 720px; margin: 30px auto; padding: 0 20px; color: #222; }
  h1 { font-size: 20px; margin: 0 0 24px; }
  pre { white-space: pre-wrap; font-family: inherit; }
  @media print { body { margin: 0; } }
</style>
</head><body>
<h1>Madhav — last ${days} days · prepared for Dr. Anand</h1>
<pre>${safe}</pre>
</body></html>`;
}
