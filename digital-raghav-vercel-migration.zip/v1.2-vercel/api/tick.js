// ============================================================================
// api/tick.js — scheduler heartbeat
// ============================================================================
// Hit by cron-job.org every minute. Runs one scheduler tick.
//
// Response is JSON for debugging via cron-job.org's history view. The body
// content doesn't matter for cron-job.org — only the HTTP status. 200 = ok.
// ============================================================================

import { isAuthorizedCron } from '../lib/tickAuth.js';
import { runTick } from '../lib/scheduler.js';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ ok: false, reason: 'method_not_allowed' });
  }
  if (!isAuthorizedCron(req)) {
    return res.status(401).json({ ok: false, reason: 'unauthorized' });
  }

  try {
    const summary = await runTick();
    const httpStatus = summary.errors.length === 0 ? 200 : 207;  // 207 = partial
    return res.status(httpStatus).json({ ok: true, ...summary });
  } catch (err) {
    console.error('[tick] fatal:', err);
    return res.status(500).json({ ok: false, reason: err.message });
  }
}
