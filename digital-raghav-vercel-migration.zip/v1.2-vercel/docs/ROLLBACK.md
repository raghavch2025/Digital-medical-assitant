# Rollback Procedures

## TL;DR
**Madhav has a working pillbox + paper Rx.** Any bot failure means he falls back to that. Zero medical risk in any rollback scenario.

## Scenarios

### A. Vercel is down completely
**Action:** None. Wait for Vercel to recover. Send Madhav a quick "bot's down for a bit, use your pillbox" message if you notice quickly.
**Why:** Vercel outages are rare and short. Switching providers in a panic causes more problems than it solves.

### B. cron-job.org is down
**Symptom:** Reminders stop firing, but the bot still responds to messages.
**Action:**
- Check status.cron-job.org
- If they're down for >30 min: log into cron-job.org and re-trigger jobs manually, or use any backup pinger (Uptime Robot, Better Stack, etc. — all free)
- Tell Madhav: "scheduler hiccup, use pillbox tonight, fixed by morning"

### C. Vercel function quota exhausted
**Symptom:** All endpoints return 429 (rate limit). Should never happen at this usage — Hobby gets 1M invocations/month, and tick uses ~43,200/month.
**Likely cause:** TICK_SECRET leaked, someone hammering /api/tick. Or runaway code.
**Action:**
- Disable cron-job.org tick job temporarily
- Check Vercel function logs for repeated identical requests
- Rotate TICK_SECRET (see MIGRATION.md "TICK_SECRET safety")

### D. Bot sends wrong/spammy messages to Madhav
**Symptom:** Bug in code, Madhav gets confused/upset messages.
**Action (immediate):** In Twilio console, change the webhook URL to anything invalid (e.g. `https://localhost/disabled`). Twilio will get 404s on inbound — Madhav's messages won't reach the bot, but the bot also can't send wrong things back. Fix the code, redeploy, restore the webhook.

### E. Wrong med fires at wrong time
**Symptom:** Madhav gets a reminder for the wrong slot.
**Likely cause:** Bad schedule edit. Check `/audit` to see what changed.
**Action:** `/undo` from your WhatsApp. The audit log + undo are exactly for this.

### F. Twilio sandbox session expired
**Symptom:** Bot can't send messages to Madhav. Replies fail with "session expired" or similar.
**Cause:** Twilio sandbox sessions expire after 72 hours of inactivity. If you're on the sandbox (not a production WhatsApp Business sender), Madhav has to re-join by texting the sandbox code to the Twilio number.
**Fix long-term:** Move from sandbox to a production WhatsApp Business sender. Twilio docs cover this.

### G. Google Sheets API quota hit
**Symptom:** Sheets reads/writes start failing with 429.
**Cause:** Vercel cold starts each tick = more reads than Railway. Or you wrote a tight loop.
**Action:** Check Google Cloud Console → APIs → Sheets API → Quotas. Default is 300 reads/minute per user, 60 writes/minute. You should be nowhere near these.

## Full rollback to Railway

If Vercel turns out to be a bad fit:

1. `railway up` from the old repo with `digital-raghav` codebase (V1.1)
2. Set the env vars in Railway as before (you'll need to re-add them since you cancelled)
3. Pay Railway $5/mo
4. Change Twilio webhook from Vercel URL back to Railway URL
5. Delete cron-job.org jobs (no longer needed)

Estimated time: 30 minutes if you still have the old Railway env vars saved somewhere. **Save them now** before deleting the Railway project.

## What to save before deleting Railway

Before you cancel/delete Railway, export:
- All env vars (copy them into a password manager note)
- The Twilio webhook URL it was using (so you can revert if needed)
- Any logs from the last 30 days (Railway → Logs → Download)

This is cheap insurance and takes 5 minutes.
