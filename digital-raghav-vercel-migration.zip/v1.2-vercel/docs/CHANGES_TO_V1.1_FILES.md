# Changes required to existing V1.1 files when moving to Vercel

Most of your V1.1 code moves to `lib/` unchanged. Three files need small edits.

## lib/sheets.js — add `replaceTab()`

Same patch as the V1.2 admin bundle. Adds an atomic "clear and replace data rows" function used by the schedule/threshold writers.

```js
/**
 * Replace all data rows in a tab (keeps the header row).
 * If the tab doesn't exist, creates it with the given headers first.
 */
export async function replaceTab(tabName, headers, rows) {
  const client = await getSheetsClient();
  const sheetId = process.env.GOOGLE_SHEET_ID;

  await ensureTab(tabName, headers);
  await client.spreadsheets.values.clear({
    spreadsheetId: sheetId,
    range: `${tabName}!A2:ZZ`,
  });
  if (rows.length === 0) return;
  await client.spreadsheets.values.update({
    spreadsheetId: sheetId,
    range: `${tabName}!A2`,
    valueInputOption: 'RAW',
    requestBody: { values: rows },
  });
}
```

## lib/parser.js — recognize slash commands

Same patch as the V1.2 admin bundle. Adds a new `ADMIN_COMMAND` type so admin slash commands don't fall through to the LLM rescue path meant for Madhav.

In the TYPES export near the top:

```js
export const TYPES = {
  // ... existing ...
  ADMIN_COMMAND: 'admin_command',
};
```

Early in the `parse()` function, before any other slash-command checks:

```js
if (/^\s*\//.test(text)) {
  return { type: TYPES.ADMIN_COMMAND, raw: text };
}
```

## lib/config.js — GOOGLE_SERVICE_ACCOUNT_JSON instead of file path

V1.1 likely reads the Google service account from a JSON file or a multi-line env var. Vercel's env var UI doesn't handle multi-line JSON gracefully, so we store it as a single-line string and parse on load.

Find the bit that loads service account credentials and change it to:

```js
function loadServiceAccount() {
  const raw = process.env.GOOGLE_SERVICE_ACCOUNT_JSON;
  if (!raw) {
    throw new Error('GOOGLE_SERVICE_ACCOUNT_JSON env var not set');
  }
  try {
    return JSON.parse(raw);
  } catch (err) {
    throw new Error('GOOGLE_SERVICE_ACCOUNT_JSON is not valid JSON: ' + err.message);
  }
}
```

When you paste the JSON into Vercel's env var UI, make sure it's all on one line. The easy way:

```bash
cat your-service-account.json | node -e "process.stdin.on('data', d => console.log(JSON.stringify(JSON.parse(d))))"
```

Copy the output, paste into Vercel.

## Everything else

No edits needed. Just `mv src/foo.js lib/foo.js` and adjust import paths if the new files use them.

## Common gotchas

### Vercel auto-parses request bodies

For `application/json` POSTs, `req.body` is already an object (don't `JSON.parse` it).
For `application/x-www-form-urlencoded` (Twilio's webhook format), `req.body` is also already parsed into an object.

V1.1's `parseInbound(req)` reads from `req.body` directly, which works on both Express and Vercel — no changes needed.

### Cold starts and the bootstrap call

Every Vercel function call MIGHT be a cold start (fresh Node process). The `ensureBootstrap()` pattern in each route handler is idempotent:

- First call: actually creates Sheet tabs if missing, seeds defaults
- Subsequent calls in the same warm instance: skipped via `bootstrapped` flag
- Cold start: runs again, but `bootstrap()` only does work if tabs are missing

This is intentionally cheap on repeat. Sheets API quota is plenty for this.

### Twilio expects a 200 fast

V1.1's webhook responds with empty TwiML after handlers finish. We keep that pattern. If Twilio doesn't get a response in 15 seconds, it retries the webhook — which means Madhav gets duplicate processing. None of our handlers should take more than 5 seconds for the kind of messages real users send.

If you ever add something slow (e.g. a long LLM call for tone analysis), respond with TwiML first and do the slow work via `setTimeout(fn, 0)` or queue it elsewhere — Vercel keeps the function instance alive briefly after `res.end()`, but not guaranteed.

For the current handlers, no changes needed.
